package ContentManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ContactServlet extends HttpServlet {
public static final long serialVersionUID=1L;
public static List <Contact> contacts=new ArrayList<>();

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException{
	String name = request.getParameter("name");
	String phone = request.getParameter("phone");
	String email = request.getParameter("email");
	
	Contact newcontect = new Contact(name, phone, email);
	contacts.add(newcontect);
	response.sendRedirect("index.html");
}


}
