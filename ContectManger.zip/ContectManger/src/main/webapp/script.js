document.addEventListener('DOMContentLoaded', () => {

    const button = document.getElementById('addBtn');
    const list = document.getElementById('contactList');

    button.addEventListener('click', () => {
        window.location.href = "Add_contact.html";
    });

    fetch("contacts")
        .then(response => response.json())
        .then(data => {
            list.innerHTML = "";
            data.forEach(contact => {
                const listItem = document.createElement('div');
                listItem.className = "contact-card";
                listItem.innerHTML = `
                    <h3>${contact.name}</h3>
                    <p>Email: ${contact.email}</p>
                    <p>Phone: ${contact.phone}</p>
                `;
                list.appendChild(listItem);
            });
        })
        .catch(error => console.error("Error fetching contacts:", error));
});
